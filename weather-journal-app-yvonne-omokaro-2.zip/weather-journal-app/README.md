# Weather-Journal App Project
This is the fourth project of the Udacity nanodegree program.

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. To achieve this, the following step will be taken:
1. Set up the project environment. This is done by first installing node.js on the system and installing express using npm (node package manager) on the application.
2. A static file should be available that will be loaded into the server.
3. Install the 'cors' package to help cors origin resource and body-parser to help send a post request to the server.
4. The local server must be fully operational, sending information to the command line via a functional callback function. That is, when the server is started, a feedback like "local-host running or port" in the terminal area of the workspace.
5. Get an API Key using  OpenWeatherMap.com.
6. Create an object in the server.js file and name it projectData to act as the app API endpoint.
7. Create a variable to save the API key generated from  OpenWeatherMap.com.
8. Set up a GET route where API cors is expected.
The server site is to retrieve the weather data that is stored there and return the data to the client site.
9. CLIENT SITE: This site is to fetch the data contained in the server site use it in the user interface.
10. Set a Post route on the server side to make a post request to the server that will be executed on the client side as asynchronous function. That is, I will have a minimum of two routes which are GET route and POST route on the server side. The function of the POST route is to capture the post data that was sent with the client side (weather data acquired) to the server.
11. The UI part of the project is where the feedback is rendered.
## Instructions
This will require modifying the `server.js` file and the `website/app.js` file. You can see `index.html` for element references, and once you are finished with the project steps, you can use `style.css` to style your application to customized perfection.

## Extras
If you are interested in testing your code as you go, you can use `tests.js` as a template for writing and running some basic tests for your code.

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + 1 + "/" + d.getDate() + "/" + d.getFullYear();


/* Global Variables */
const generate = document.getElementById("generate"),
      zip = document.getElementById("zip"),
      feelings = document.querySelector("#feelings"),
      content = document.querySelector("#content"),
      temp = document.querySelector("#temp"),
      date = document.querySelector("#date"),
      city = document.querySelector("#city");


// API Variables
const primaryURL = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = '&appid=eeb87100897a38af2b1f7fa0f41fef44&units=imperial';


//Event Listener function for the generate button
generate.addEventListener("click", (evt) => {
    evt.preventDefault(); //This command is useful in preventing the work from self-submission and refreshing the output
    const dynamicURL = `${primaryURL}${zip.value}${apiKey}`;// Tis part is to generate the url.
    collectData(dynamicURL) //This is useful in collecting the data from the OpenWeatherMap API
        .then((data) => {
            collateData(data) //This is a callback function which is used to extract the needed data
                .then((info) => {
                    sendData("/add", info) //This is a call function which converts the data sent to JSON and subsequently send it to the server
                        .then(() => {
                            retrieveData("/all") //This is a callback function which is used to retrieve data from the server
                                .then((data) => {
                                    updateInterface(data); //This is needed to Update the interface with the data asynchronous
                                });
                        });
                });
        });
});

// This is an async function which is useful in retrieving data from the OpenWeatherMap API
const collectData = async (url) => {
    try {
        const result = await fetch(url);
        const data = await result.json();
        if (data.cod === 200) {
            return (data);
        }
    }
    catch (err) {
        console.error("Error found : " + err);
    }
}

//This is the async function that helps to cull the required data
const collateData = async (data) => {
    await data;
    try {
        if (data) {
            const icon = data.weather[0].icon;
            const mainWeather = data.weather[0].main;
            const info = {
                date: newDate,
                feelings: feelings.value,
                temp: `${data.main.temp}°`,
                weather: data.weather[0].description,
                icon: icon,
                mainWeather: mainWeather,
                name: data.name
            }
            return (info);
        }
        else {
            return data;
        };
    }
    catch (err) {
        console.error("Error found" + err);
    }
}

//This ia an async function which helps in transform the data received to JSON and subsequently transmit it to the server
const sendData = async (url = "", data = {}) => {
    try {
        const value = await fetch(url, {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "content-Type": "application/json"
            },
            body: JSON.stringify(data)
        })
        return value;
    }
    catch (err) {
        console.error("Error found " + err)
    }
}

//This is an async function that recover data from the server
const retrieveData = async () => {
    const data = await fetch('/all');
    try {
        // This is where the data is modified to JSON
        const res = await data.json();
        return res;
    }
    catch (err) {
        console.error("Error found " + err);
    }
}

//This is an async function used to dynamically update the browser interface with the data
const updateInterface = async (data) => {
    try {
        const response = await data;
        if (response.date) {
            const mainWeather = response.mainWeather;
            date.innerHTML = `${response.date}`;
            temp.innerHTML = response.temp;
            content.innerHTML = response.feelings;
            city.innerHTML = response.name;
        } else {
            alert("Input Error!\nCheck zip code and try again...")
        }
    }
    catch (err) {
        console.error("Error : " + err);
    }
}